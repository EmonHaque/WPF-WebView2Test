﻿
class HeaderAreaWidthConverter : IMultiValueConverter
{
    public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture) {
        var gridWidth = (double)values[0];
        var buttonsWidth = (double)values[1];
        var addWidth = (double)values[2];
        return gridWidth - buttonsWidth - addWidth - 15;
    }

    public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture) {
        throw new NotImplementedException();
    }
}

