﻿
class WebWindow : Window
{
    Border border;
    TabControl tabs;

    public WebWindow() {
        Height = 640;
        Width = 800;
        WindowStartupLocation = WindowStartupLocation.CenterScreen;
        WindowStyle = WindowStyle.None;
        AllowsTransparency = true;
        Title = "Browser";
        WindowChrome.SetWindowChrome(this, new WindowChrome() {
            ResizeBorderThickness = new Thickness(0, 0, 5, 5),
            CaptionHeight = 0
        });
        tabs = new TabControl() {
            Template = new TabControlTemplate(minimize, resize, close, add)
        };
        border = new Border() {
            Background = Brushes.White,
            CornerRadius = new CornerRadius(5),
            Child = tabs
        };
        AddVisualChild(border);
        tabs.Items.Add(new Page());
        tabs.Items.Add(new Page());
        tabs.Items.Add(new Page());
        border.MouseMove += move;
    }

    void add() {
        var page = new Page();
        tabs.Items.Add(page);
        tabs.SelectedItem = page;
    }

    void minimize() => WindowState = WindowState.Minimized;
    void resize() {
        if (WindowState == WindowState.Maximized) {
            ResizeMode = ResizeMode.CanResizeWithGrip;
            WindowState = WindowState.Normal;
            //maxRestore.Icon = Icons.Maximize;
            //maxRestore.ToolTip = "Maximize";
        }
        else {
            ResizeMode = ResizeMode.NoResize;
            WindowState = WindowState.Maximized;
            //maxRestore.Icon = Icons.Restore;
            //maxRestore.ToolTip = "Restore";
        }
    }
    void close() => Application.Current.Shutdown();
    void move(object sender, MouseEventArgs e) {
        if (e.LeftButton == MouseButtonState.Pressed) DragMove();
    }
    protected override Visual GetVisualChild(int index) => border;
    protected override int VisualChildrenCount => 1;
}
