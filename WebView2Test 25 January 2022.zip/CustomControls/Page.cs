﻿class Page : TabItem
{
    WebView2 web;
    CoreWebView2 view;
    TextBox box;
    TextBlock headerBlock;
    ActionButton back, forward, reload, favorite, print;
    MenuItem closeMenu;
    public Page() {
        headerBlock = new TextBlock() { Text = "New Tab"};
        closeMenu = new MenuItem() { Header = "Close" };
        closeMenu.Click += CloseMenu_Click;
        Header = new ContentControl() {
            Content = headerBlock,
            ContextMenu = new ContextMenu() { Items = {closeMenu }}
        };
        Template = new TabItemTemplate(close);
        box = new TextBox();
        web = new WebView2();
       
        back = new ActionButton() { Icon = Icons.Back, Space = true, Command = web.GoBack };
        forward = new ActionButton() { Icon = Icons.Forward, Space = true, Command = web.GoForward };
        reload = new ActionButton() { Icon = Icons.Refresh, Space = true, Command = web.Reload };
        favorite = new ActionButton() { Icon = Icons.Favorite, Space = true };
        print = new ActionButton() { Icon = Icons.Print, Space = true };
        

        Grid.SetColumn(forward, 1);
        Grid.SetColumn(reload, 2);
        Grid.SetColumn(box, 3);
        Grid.SetColumn(favorite, 4);
        Grid.SetColumn(print, 5);
        Grid.SetRow(web, 1);
        Grid.SetColumnSpan(web, 6);
        Content = new Grid() {
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            ColumnDefinitions = {
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto }
            },
            Children = { back, forward, reload, box, favorite, print, web },
            Margin = new Thickness(5)
        };
        Loaded += onLoaded;
        box.KeyUp += onKeyUp;
        Unloaded += onUnloaded;
    }

    private void CloseMenu_Click(object sender, RoutedEventArgs e) => close();

    async void onLoaded(object sender, RoutedEventArgs e) {
        await web.EnsureCoreWebView2Async();
        view = web.CoreWebView2;
        view.DocumentTitleChanged += onTitleChanged;
    }

    void onTitleChanged(object? sender, object e) {
        headerBlock.Text = view.DocumentTitle;
    }

    void onUnloaded(object sender, RoutedEventArgs e) {
        Loaded -= onLoaded;
        box.KeyUp -= onKeyUp;
        Unloaded -= onUnloaded;
        
        closeMenu.Click -= CloseMenu_Click;
        if(view != null) view.DocumentTitleChanged -= onTitleChanged;
    }
    void close() => ((TabControl)Parent).Items.Remove(this);
    void onKeyUp(object sender, KeyEventArgs e) {
        if (e.Key != Key.Enter) return;
        view.Navigate("http://www." + box.Text + ".com");
    }
    protected override void OnSelected(RoutedEventArgs e) {
        base.OnSelected(e);
        FocusManager.SetIsFocusScope(this, true);
        box.Focus();
    }
}

