﻿class SStackPanel : StackPanel
{
    Size reqSize;

    protected override Size MeasureOverride(Size constraint) {
        reqSize = new Size();
        foreach (FrameworkElement child in Children) {
            child.Measure(constraint);
            reqSize.Width += child.DesiredSize.Width;
            reqSize.Height = child.DesiredSize.Height;
        }
        return base.MeasureOverride(constraint);
    }
    protected override Size ArrangeOverride(Size arrangeSize) {
        if (reqSize.Width <= MaxWidth) return base.ArrangeOverride(arrangeSize);
        double x = 0;
        double width = 0;
        foreach (FrameworkElement child in Children) {
            width = MaxWidth / reqSize.Width * child.DesiredSize.Width;
            child.Arrange(new Rect(x, 0, width, arrangeSize.Height));
            x += width;
        }
        return new Size(MaxWidth, arrangeSize.Height);
    }

    public new double MaxWidthProperty {
        get { return (double)GetValue(MaxWidthPropertyProperty); }
        set { SetValue(MaxWidthPropertyProperty, value); }
    }

    public static readonly DependencyProperty MaxWidthPropertyProperty =
        DependencyProperty.Register("MaxWidthProperty", typeof(double), typeof(SStackPanel), new FrameworkPropertyMetadata() {
            DefaultValue = 0d,
            AffectsArrange = true
        });
}
