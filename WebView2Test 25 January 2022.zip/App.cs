﻿
class App : Application
{
    [STAThread]
    static void Main(string[] args) => new App().Run();
    protected  override void OnStartup(StartupEventArgs e) {
        base.OnStartup(e);
        //Current.Resources.Add(SystemParameters.VerticalScrollBarWidthKey, 12d);
        //Current.Resources.Add(SystemParameters.HorizontalScrollBarHeightKey, 12d);
        //Control.StyleProperty.OverrideMetadata(typeof(ScrollBar), new FrameworkPropertyMetadata() {
        //    DefaultValue = new Style() {
        //        Setters = { new Setter(ScrollBar.TemplateProperty, new VScrollTemplate()) },
        //        Triggers = {
        //                new Trigger() {
        //                    Property = ScrollBar.OrientationProperty,
        //                    Value = Orientation.Horizontal,
        //                    Setters = { new Setter(ScrollBar.TemplateProperty, new HScrollTemplate()) }
        //                }
        //            }
        //    }
        //});

        App.Current.MainWindow = new WebWindow();
        App.Current.MainWindow.Show();
    }
}

