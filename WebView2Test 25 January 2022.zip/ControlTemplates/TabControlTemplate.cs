﻿class TabControlTemplate : ControlTemplate
{
    public TabControlTemplate(Action minAction, Action maxAction, Action closeAction, Action addAction) {
        TargetType = typeof(TabControl);

        var grid = new FrameworkElementFactory(typeof(Grid)) { Name = "grid"};
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col3 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var row1 = new FrameworkElementFactory(typeof(RowDefinition));
        var row2 = new FrameworkElementFactory(typeof(RowDefinition));
        var headerPanel = new FrameworkElementFactory(typeof(SStackPanel));
        var buttonsPanel = new FrameworkElementFactory(typeof(StackPanel)) { Name = "buttons" };
        var contentPanel = new FrameworkElementFactory(typeof(Border));
        var content = new FrameworkElementFactory(typeof(ContentPresenter));

        var add = new FrameworkElementFactory(typeof(ActionButton)) { Name = "add" };
        var minimize = new FrameworkElementFactory(typeof(ActionButton));
        var maximize = new FrameworkElementFactory(typeof(ActionButton));
        var close = new FrameworkElementFactory(typeof(ActionButton));

        add.SetValue(ActionButton.IconPropertyProperty, Icons.Add);
        minimize.SetValue(ActionButton.IconPropertyProperty, Icons.Minimize);
        maximize.SetValue(ActionButton.IconPropertyProperty, Icons.Maximize);
        close.SetValue(ActionButton.IconPropertyProperty, Icons.Close);

        add.SetValue(ActionButton.ActionPropertyProperty, addAction);
        minimize.SetValue(ActionButton.ActionPropertyProperty, minAction);
        maximize.SetValue(ActionButton.ActionPropertyProperty, maxAction);
        close.SetValue(ActionButton.ActionPropertyProperty, closeAction);

        add.SetValue(Grid.HorizontalAlignmentProperty, HorizontalAlignment.Left);
        add.SetValue(Grid.VerticalAlignmentProperty, VerticalAlignment.Center);
        add.SetValue(ActionButton.MarginProperty, new Thickness(5, 0, 0, 0));
        maximize.SetValue(ActionButton.MarginProperty, new Thickness(5, 0, 5, 0));
        buttonsPanel.SetValue(ActionButton.MarginProperty, new Thickness(5));

        headerPanel.SetBinding(StackPanel.MaxWidthProperty, new MultiBinding() {
            Converter = new HeaderAreaWidthConverter(),
            Bindings = {
                new Binding(nameof(Grid.ActualWidth)){ ElementName = "grid" },
                new Binding(nameof(StackPanel.ActualWidth)){ ElementName = "buttons" },
                new Binding(nameof(ActionButton.ActualWidth)){ ElementName = "add" }
            }
        });
        headerPanel.SetValue(StackPanel.OrientationProperty, Orientation.Horizontal);
        buttonsPanel.SetValue(StackPanel.OrientationProperty, Orientation.Horizontal);

        row1.SetValue(RowDefinition.HeightProperty, new GridLength(1, GridUnitType.Auto));
        col1.SetValue(ColumnDefinition.WidthProperty, new GridLength(1, GridUnitType.Auto));
        col3.SetValue(ColumnDefinition.WidthProperty, new GridLength(1, GridUnitType.Auto));

        add.SetValue(Grid.ColumnProperty, 1);
        buttonsPanel.SetValue(Grid.ColumnProperty, 2);
        contentPanel.SetValue(Grid.RowProperty, 1);
        contentPanel.SetValue(Grid.ColumnSpanProperty, 3);
        
        headerPanel.SetValue(TabPanel.IsItemsHostProperty, true);
        content.SetValue(ContentPresenter.ContentSourceProperty, nameof(TabControl.SelectedContent));

        buttonsPanel.AppendChild(minimize);
        buttonsPanel.AppendChild(maximize);
        buttonsPanel.AppendChild(close);
        contentPanel.AppendChild(content);
        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(col3);
        grid.AppendChild(row1);
        grid.AppendChild(row2);
        //grid.AppendChild(headerScroll);
        grid.AppendChild(headerPanel);
        grid.AppendChild(add);
        grid.AppendChild(buttonsPanel);
        grid.AppendChild(contentPanel);

        VisualTree = grid;
    }
}
