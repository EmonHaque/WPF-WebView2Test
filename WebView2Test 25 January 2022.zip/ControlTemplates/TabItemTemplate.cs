﻿
class TabItemTemplate : ControlTemplate
{
    public TabItemTemplate(Action close) {
        TargetType = typeof(TabItem);
        var border = new FrameworkElementFactory(typeof(Border)) { Name = "border" };
        var grid = new FrameworkElementFactory(typeof(Grid));
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var header = new FrameworkElementFactory(typeof(ContentPresenter));
        var button = new FrameworkElementFactory(typeof(ActionButton)) { Name = "button" };

        col1.SetValue(ColumnDefinition.WidthProperty, GridLength.Auto);
        border.SetValue(Border.BorderThicknessProperty, new Thickness(1));
        border.SetValue(Border.MarginProperty, new Thickness(1, 1, 1, 0));
        border.SetValue(Border.BorderBrushProperty, Brushes.CornflowerBlue);
        border.SetValue(Border.CornerRadiusProperty, new CornerRadius(5, 5, 0, 0));

        header.SetValue(ContentPresenter.MarginProperty, new Thickness(2, 0, 0, 2));
        header.SetValue(ContentPresenter.VerticalAlignmentProperty, VerticalAlignment.Center);
        header.SetValue(ContentPresenter.HorizontalAlignmentProperty, HorizontalAlignment.Left);
        header.SetValue(ContentPresenter.ContentSourceProperty, nameof(TabItem.Header));

        button.SetValue(ActionButton.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        button.SetValue(ActionButton.IconPropertyProperty, Icons.CloseCircle);
        button.SetValue(ActionButton.ActionPropertyProperty, close);
        button.SetValue(ActionButton.WidthProperty, 14d);
        button.SetValue(ActionButton.HeightProperty, 14d);
        button.SetValue(Grid.ColumnProperty, 1);
        button.SetValue(Button.MarginProperty, new Thickness(5, 0, 5, 0));

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(header);
        grid.AppendChild(button);
        border.AppendChild(grid);
        VisualTree = border;

        Triggers.Add(new Trigger() {
            Property = TabItem.IsMouseOverProperty,
            Value = true,
            Setters = {
                new Setter() {
                    TargetName = "border",
                    Property = Border.BackgroundProperty,
                    Value = Brushes.Coral
                }
            }
        });

        Triggers.Add(new Trigger() {
            Property = TabItem.IsSelectedProperty,
            Value = true,
            Setters = {
                new Setter() {
                    TargetName = "border",
                    Property = Border.BackgroundProperty,
                    Value = Brushes.LightBlue
                },
                new Setter() {
                    TargetName = "border",
                    Property = Border.BorderThicknessProperty,
                    Value = new Thickness(1,1,1,0)
                },
                new Setter() {
                    TargetName = "border",
                    Property = Border.BorderBrushProperty,
                    Value = Brushes.Blue
                },
            }
        });
        
    }
}
